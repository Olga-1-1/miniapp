import React from "react";
import ReactDOM from "react-dom/client";
import JoblyApp from "./JoblyApp.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <JoblyApp />
  </React.StrictMode>
);